-----------------------------------------------------------

               Atomic FTP Server v0.5
            
          Coded by AlphaSND with PureBasic

-----------------------------------------------------------

Overview:

  Atomic Web Server is a partially working ftp server, which use
  the advanced network functions of PureBasic. It's not finished
  (and will probably never be), it's just to demonstrate the
  capability of PureBasic.
  
Licence:

  This server is freeware, can be modified and upgraded by anyone, but
  its name must remain intact (or contact me at alphasnd@purebasic.com).  

Features:

  - 15 Kb executable
  - GUI (one window :-)
  - Support of the following commands: HELP, LIST, PASS, PORT, PWD, SYST, USER
  - Very fast

Installation:

  Copy the .exe where you need. Create a 'ftp' directory and put your ftp 
  files inside..


      Enjoy !
      
          AlphaSND.

