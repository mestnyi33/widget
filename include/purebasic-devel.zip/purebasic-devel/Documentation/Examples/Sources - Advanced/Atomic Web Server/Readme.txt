-----------------------------------------------------------

               Atomic Web Server v1.0
            
          Coded by AlphaSND with PureBasic

-----------------------------------------------------------

Overview:

  Atomic Web Server is a fully working web server, which use
  the advanced network functions of PureBasic.
  
Licence:

  This server is freeware, can be modified and upgraded by anyone, but
  its name must remain intact (or contact me at alphasnd@purebasic.com).  

Features:

  - 15 Kb executable
  - GUI (one window :-)
  - Support any MIME types
  - Support drawers inside the web site
  - Customizable error page and default page
  - Handle up to 255 connections simultaneously
  - Very fast

Installation:

  Copy the .exe where you need. Create a 'www' directory and create the
  2 following files inside the 'www' directory: 
    - AtomicWebServer_Error.html
    - Index.html


      Enjoy !
      
          AlphaSND.

