
--------------------------------------------------

              Quake 3 Arena Launcher 
                      
                AlphaSND & JunIor

--------------------------------------------------


Purpose:
--------

  The mods for Quake3 only works for a specific version
of Quake 3: the 1.17 or 1.27. This is annoying as two
version of Quake 3 must be installed on the same computer.
This launcher switch automatically from one version to
another only without to have both version, but only the
2 executables.


Features:
---------

	- Automatic switching between 1.17 <-> 1.27
	- Unlimited number of mods
	- Info file for each mods
	- Automatic copy of a default.cfg to normal cfg in the mod
	  directory
	- 21 Kb, standalone program
	- Source code provided !
	- Freeware


Installation:
-------------
  
  - Install a Quake 3 v1.27 correctly. Find a v1.17 executable
(on the ID software site) or get it from the original CD.

  - Rename the 1.17 executable to 'Quake3.1.17.exe' and put
    it in the Quake 3 directory
    
  - Rename the 1.27 executable to 'Quake3.exe'
  
  
Editing the .prefs:
-------------------
  
  There are 3 lines per mods:
  - Label (displayed in the Quake3 launcher
  - Directory name
  - Version (1.17 or 1.27)
  

Adding a .info file:
--------------------

  Go into the mod drawer and create a file 'DirectoryName.info'
Edit it and that's all.


  Coded in 1 hour in PureBasic 2.30 ! Check it out at www.purebasic.com
  
                
            AlphaSND & JunIor.